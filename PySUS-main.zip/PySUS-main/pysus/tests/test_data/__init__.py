u"""
Created on 12/12/18
by fccoelho
license: GPL V3 or Later
"""
