#!/bin/bash

exec jupyter-lab --browser='firefox'  --allow-root --NotebookApp.token='' --NotebookApp.password=''
